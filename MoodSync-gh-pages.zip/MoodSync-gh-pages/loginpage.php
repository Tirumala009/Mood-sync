<html>
<body>

Welcome <?php echo $_POST["uname"]; ?><br>
Your email address is: <?php echo $_POST["psw"]; ?>

</body>
</html>